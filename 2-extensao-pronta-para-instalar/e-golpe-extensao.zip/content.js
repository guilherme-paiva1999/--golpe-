(() => {
  'use strict';
  if (window.__pgCarregado) return;
  window.__pgCarregado = true;

  // ---------- Estado e configuração ----------
  let ativo = true;
  let config = { limite: 3, imagens: false, modoSimples: false, vozAutomatica: false, daltonico: false };
  let pessoa = null;                       // pessoa de confiança (fica só neste computador)
  let siteRes = null;
  let avisoSite = null;
  let fecharAvisoAtual = null;
  let avisouPagamento = false;
  let rodadas = 0;

  try {
    chrome.storage.local.get(['config', 'pessoaConfianca']).then((d) => {
      if (d.config) Object.assign(config, d.config);
      pessoa = d.pessoaConfianca || null;
    }).catch(() => {});
    chrome.storage.onChanged.addListener((mud) => {
      if (mud.config && mud.config.newValue) Object.assign(config, mud.config.newValue);
      if (mud.pessoaConfianca) pessoa = mud.pessoaConfianca.newValue || null;
    });
  } catch (e) { /* contexto inválido */ }

  // ---------- Utilidades ----------
  function el(tag, attrs, ...filhos) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    }
    for (const f of filhos) e.append(f);
    return e;
  }

  // Avisos: cor + ícone + palavra (nunca só cor), contraste alto, foco visível.
  const CSS = `
    :host{all:initial}
    *{box-sizing:border-box;font-family:Arial,Helvetica,sans-serif}
    .faixa{font-size:18px;line-height:1.5;padding:16px 20px;box-shadow:0 2px 12px rgba(0,0,0,.35)}
    .faixa:focus-visible{outline:4px solid #fff;outline-offset:-8px}
    .atencao{background:#f9a825;color:#000}
    .perigo{background:#c62828;color:#fff}
    .cab{display:flex;gap:14px;align-items:center}
    .ico{width:48px;height:48px;flex:none}
    .ico.mini{width:30px;height:30px}
    .palavra{font-weight:bold;font-size:15px;letter-spacing:.14em}
    .titulo{font-weight:bold;font-size:24px;line-height:1.2}
    .sub{font-weight:bold;margin-top:12px}
    ul{margin:4px 0 0;padding-left:24px}
    .passo{margin-top:12px;padding:8px 12px;border:2px solid currentColor;border-radius:6px}
    .grande{font-size:24px}
    .grande .titulo{font-size:32px}
    .grande .palavra{font-size:18px}
    .grande .ico{width:64px;height:64px}
    .grande button{font-size:22px;padding:12px 18px}
    button{font-size:18px;padding:8px 14px;margin:12px 10px 0 0;cursor:pointer;border-radius:6px;border:2px solid #000;background:#fff;color:#000}
    button:focus-visible{outline:4px solid #1565c0;outline-offset:2px;box-shadow:0 0 0 7px #fff}
    .aviso{display:flex;flex-wrap:wrap;gap:10px;align-items:center;background:#c62828;color:#fff;font-size:18px;line-height:1.4;padding:12px 16px;margin:4px 0;border-radius:6px}
    .aviso button{margin:0;font-size:16px;padding:6px 12px}
    /* Tela cheia no estilo de cartaz de campanha (o mesmo da tela de bloqueio) */
    .tela{position:fixed;inset:0;overflow-y:auto;overflow-x:hidden;color:#fff;font:19px/1.5 Arial,Helvetica,sans-serif;text-align:left;
      --fundo:#d4151c;--fundo2:#a90e14;--am:#ffd21f;
      background:radial-gradient(ellipse at 30% 0%,var(--fundo) 0%,var(--fundo) 55%,var(--fundo2) 100%)}
    .tela.daltonico{--fundo:#24558f;--fundo2:#173b66}
    .tela.grande{font-size:23px}
    .zebra{position:fixed;left:0;top:0;bottom:0;width:26px;background:repeating-linear-gradient(-45deg,#111 0 16px,transparent 16px 32px)}
    .miolo{position:relative;max-width:820px;margin:0 auto;padding:34px 28px 40px 58px;display:flex;flex-direction:column;gap:20px}
    .tela .caps,.tela .caps *{font-family:'EGolpeAnton',Impact,'Arial Narrow',sans-serif;text-transform:uppercase;font-weight:400;line-height:.95}
    .topo{display:grid;grid-template-columns:1fr auto;align-items:center;gap:10px}
    .h1{margin:0;font-size:clamp(54px,10vw,104px)}
    .h1 .l1{display:block}
    .h1 .l2{display:inline-block;white-space:nowrap;background:#111;color:#fff;padding:.04em .16em .02em;transform:rotate(-2.5deg);margin-top:.06em}
    .sub{margin:14px 0 0;font-size:1.25em;line-height:1.3;font-weight:bold}
    .host{display:inline-block;margin-top:14px;background:#fff;color:#111;font:bold .95em Consolas,monospace;padding:8px 12px;overflow-wrap:anywhere;max-width:100%}
    .tri{width:clamp(130px,24vw,230px);height:auto;transform:rotate(9deg);filter:drop-shadow(0 18px 16px rgba(0,0,0,.4))}
    .conf{border-top:4px solid #fff;padding-top:14px;display:flex;align-items:flex-end;gap:14px;flex-wrap:wrap}
    .num{font-size:clamp(84px,14vw,124px);color:var(--am);line-height:.85}
    .rot{font-size:clamp(26px,4.4vw,38px);padding-bottom:4px}
    .conf-txt{margin:0;width:100%}
    .grito{margin:0;font-size:clamp(32px,5.4vw,48px);line-height:1}
    .grito span{color:var(--am)}
    .calmo{margin:-6px 0 0}
    .acoes{display:flex;flex-direction:column;gap:14px}
    .tela button{margin:0;font:inherit;cursor:pointer;border-radius:3px}
    .tela button:focus-visible{outline:4px solid #fff;outline-offset:4px;box-shadow:none}
    .tela button.seguro{background:var(--am);color:#111;border:0;padding:18px 24px;font-size:clamp(28px,4.4vw,38px);box-shadow:0 6px 0 #111}
    .tela button.grandao{display:flex;align-items:center;gap:16px;text-align:left;padding:16px 20px;border:0;width:100%}
    .grandao .t{font-size:clamp(24px,3.6vw,30px);display:block}
    .tela button.pessoa{background:#fff;color:#111}
    .tela button.pessoa svg{width:50px;height:50px;flex:none}
    .tela button.ra{background:#056734;color:#fff;flex-wrap:wrap}
    .logo-ra{background:#fff;padding:8px 12px;display:inline-flex;flex:none}
    .logo-ra img{height:30px;width:auto;display:block}
    .h2{margin:0 0 8px;font-size:clamp(28px,4.4vw,36px)}
    .lista{list-style:none;margin:0;padding:0}
    .lista li{position:relative;padding:8px 0 8px 40px;border-top:2px solid rgba(255,255,255,.35)}
    .lista li::before{content:'!';position:absolute;left:0;top:8px;width:28px;height:28px;background:var(--am);color:#111;font:20px/28px 'EGolpeAnton',Impact,sans-serif;text-align:center}
    .rodape{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;border-top:4px solid #fff;padding-top:14px}
    .tela button.leve{background:transparent;color:#fff;border:2px solid #fff;padding:10px 16px;font-size:.9em;font-weight:bold}
    .tela button.link{background:none;border:0;color:#fff;text-decoration:underline;font-size:.85em;padding:6px 0}
    @media (max-width:560px){.miolo{padding:24px 16px 32px 42px}.zebra{width:18px}.topo{grid-template-columns:1fr}.tri{position:absolute;right:10px;top:16px;width:110px}}`;

  // Avisos ficam em Shadow DOM fechado: o CSS e o JS do site não os alcançam.
  function criarCaixa(estilo) {
    const host = document.createElement('div');
    host.setAttribute('data-pg', '');
    for (const [k, v] of Object.entries(estilo)) host.style.setProperty(k, v, 'important');
    const root = host.attachShadow({ mode: 'closed' });
    root.appendChild(el('style', {}, CSS));
    return { host, root };
  }

  // Perigo = octógono com X (parar). Atenção = triângulo com ! (cuidado).
  const SVG = 'http://www.w3.org/2000/svg';
  function icone(tipo, mini) {
    const s = document.createElementNS(SVG, 'svg');
    s.setAttribute('viewBox', '0 0 32 32');
    s.setAttribute('aria-hidden', 'true');
    s.setAttribute('class', 'ico' + (mini ? ' mini' : ''));
    const forma = document.createElementNS(SVG, 'path');
    const sinal = document.createElementNS(SVG, 'path');
    if (tipo === 'perigo') {
      forma.setAttribute('d', 'M11 2h10l9 9v10l-9 9H11l-9-9V11z');
      forma.setAttribute('fill', '#fff');
      sinal.setAttribute('d', 'M11.500 11.500l9 9M20.500 11.500l-9 9');
      sinal.setAttribute('stroke', '#c62828');
    } else {
      forma.setAttribute('d', 'M16 2.500L30.500 28.500H1.500z');
      forma.setAttribute('fill', '#000');
      sinal.setAttribute('d', 'M16 11v8.500M16 23.500v.5');
      sinal.setAttribute('stroke', '#f9a825');
    }
    sinal.setAttribute('fill', 'none');
    sinal.setAttribute('stroke-width', '3');
    sinal.setAttribute('stroke-linecap', 'round');
    s.append(forma, sinal);
    return s;
  }

  // Leitura em voz alta (quem não lê bem, ou prefere ouvir). Clicar de novo para parar.
  function botaoOuvir(texto) {
    if (!('speechSynthesis' in window)) return null;
    return el('button', {
      type: 'button',
      onclick: () => {
        try {
          const s = window.speechSynthesis;
          if (s.speaking) { s.cancel(); return; }
          const u = new SpeechSynthesisUtterance(texto);
          u.lang = 'pt-BR';
          u.rate = 0.9;
          s.speak(u);
        } catch (e) { /* sem voz disponível */ }
      }
    }, 'Ouvir o aviso');
  }

  async function enviar(msg) {
    if (!ativo) return null;
    if (!chrome.runtime || !chrome.runtime.id) { desligar(); return null; }
    try {
      return await chrome.runtime.sendMessage(msg);
    } catch (e) {
      if (String(e && e.message).includes('context invalidated')) desligar();
      return null;
    }
  }

  // ---------- 1) Aviso sobre o site: tela cheia vermelha com PARE ----------
  const PASSOS = {
    perigo: 'Feche esta página. Não digite senha, CPF nem dados do cartão. Se chegou por mensagem, apague a mensagem.',
    atencao: 'Antes de pagar, abra o site oficial digitando o endereço você mesmo e confira o CNPJ da loja.'
  };

  // Desenhos fixos do cartaz (texto estático da extensão, nunca vindo da página).
  const DESENHOS = {
    tri: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 200" class="tri" aria-hidden="true">' +
      '<path d="M118 14 L214 184 Q218 194 206 194 L30 194 Q18 194 24 184 Z" fill="#b88a00"/>' +
      '<path d="M104 8 Q110 0 116 8 L208 172 Q214 184 200 184 L20 184 Q6 184 12 172 Z" fill="#ffd21f"/>' +
      '<path d="M106 34 Q110 28 114 34 L184 160 Q187 166 180 166 L40 166 Q33 166 36 160 Z" fill="none" stroke="#111" stroke-width="10" stroke-linejoin="round"/>' +
      '<path d="M110 70 L110 118" stroke="#111" stroke-width="18" stroke-linecap="round"/><circle cx="110" cy="144" r="10" fill="#111"/></svg>',
    balao: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60" aria-hidden="true">' +
      '<path d="M30 5C15 5 4 15 4 28c0 7 3 13 9 17l-3 11 12-7c2.5.6 5 .9 8 .9 15 0 26-10 26-22S45 5 30 5z" fill="#111"/>' +
      '<path d="M30 15v16" stroke="#ffd21f" stroke-width="6" stroke-linecap="round"/><circle cx="30" cy="40" r="3.6" fill="#ffd21f"/></svg>'
  };
  function desenho(nome) {
    return document.importNode(new DOMParser().parseFromString(DESENHOS[nome], 'image/svg+xml').documentElement, true);
  }

  // Letra condensada do cartaz (Anton, licença OFL), embutida na extensão. Sem ela, usa Impact.
  let fonteCarregada = false;
  function carregarFonte() {
    if (fonteCarregada) return;
    fonteCarregada = true;
    try {
      const f = new FontFace('EGolpeAnton', 'url("' + chrome.runtime.getURL('fontes/anton.woff2') + '")');
      document.fonts.add(f);
      f.load().catch(() => {});
    } catch (e) { /* a página pode bloquear: fica a letra reserva */ }
  }

  function mostrarAvisoSite(res) {
    if (avisoSite) return;
    const perigo = res.nivel === 'perigo';
    const nivel = perigo ? 'perigo' : 'atencao';
    const simples = !!config.modoSimples;
    const motivos = res.motivos.slice(0, simples ? 2 : 4);
    const titulo = res.comercio
      ? (perigo ? 'Esta loja tem cara de golpe' : 'Esta loja ainda não provou ser confiável')
      : (perigo ? 'Este site pode ser um golpe' : 'Este site é suspeito');
    // Porcentagem: só é confiável quem passa do limite (mais de 80% no rigor padrão).
    const limiteConf = res.limite || (config.rigor === 'normal' ? 60 : 80);
    const confNum = res.confianca !== undefined ? res.confianca : (typeof res.pontos === 'number' ? Math.max(0, 100 - res.pontos) : null);
    const confTexto = res.confianca !== undefined
      ? 'Confiança: ' + res.confianca + '%. Para ser confiável, precisa passar de ' + limiteConf + '%.'
      : (typeof res.pontos === 'number' ? 'Confiança: ' + Math.max(0, 100 - res.pontos) + '%. Para ser confiável, precisa passar de ' + limiteConf + '%.' : '');

    const { host, root } = criarCaixa({
      position: 'fixed', inset: '0', 'z-index': '2147483647', display: 'block'
    });

    // Trava a página por trás: sem rolar, sem digitar, sem clicar.
    const html = document.documentElement;
    const overflowAntes = html.style.getPropertyValue('overflow');
    html.style.setProperty('overflow', 'hidden', 'important');
    if (document.body) document.body.inert = true;
    const fechar = () => {
      host.remove();
      if (overflowAntes) html.style.setProperty('overflow', overflowAntes); else html.style.removeProperty('overflow');
      if (document.body) document.body.inert = false;
      fecharAvisoAtual = null;
    };
    fecharAvisoAtual = fechar;

    let confirmou = false;
    const voltar = el('button', { type: 'button', class: 'seguro caps', onclick: () => enviar({ tipo: 'voltar' }) }, 'Voltar para a segurança');
    const continuar = el('button', {
      type: 'button', class: 'link',
      onclick: () => {
        if (!confirmou) { confirmou = true; continuar.textContent = 'Tem certeza? Clique de novo para entrar'; return; }
        enviar({ tipo: 'parar-fala' });
        fechar();
      }
    }, 'Continuar mesmo assim (não recomendado)');

    const dominioRA = (res.dominio || location.hostname).replace(/^www\./, '');
    // Botão grande: uma fonte externa, além do nosso aviso. Verde da marca, com a logo numa etiqueta branca.
    const logo = el('img', { src: chrome.runtime.getURL('icons/reclameaqui.png'), alt: '' });
    const chip = el('span', { class: 'logo-ra', 'aria-hidden': 'true' }, logo);
    logo.addEventListener('error', () => chip.remove());          // se a página bloquear a imagem, fica só o texto
    const textoRA = el('span', { class: 't caps' }, 'Verificar no Reclame Aqui');
    const ra = el('button', {
      type: 'button', class: 'grandao ra',
      onclick: () => {
        try { navigator.clipboard.writeText(dominioRA).catch(() => {}); } catch (e) { /* sem área de transferência */ }
        window.open('https://www.reclameaqui.com.br/detector-site-confiavel/', '_blank', 'noopener');
        textoRA.textContent = 'Endereço copiado (' + dominioRA + '): cole no Reclame Aqui';
      }
    }, chip, textoRA);
    const acoes = el('div', { class: 'acoes' }, voltar);
    const P = self.EGolpePessoa;
    if (P && P.valida(pessoa)) {
      const msg = P.mensagem(pessoa.nome, location.href);
      const link = P.linkWhats(pessoa, msg) || P.linkEmail(pessoa, msg);
      acoes.append(el('button', {
        type: 'button', class: 'grandao pessoa',
        onclick: () => { if (link.startsWith('mailto:')) location.href = link; else window.open(link, '_blank', 'noopener'); }
      }, desenho('balao'), el('span', { class: 't caps' }, 'Perguntar para ' + P.primeiroNome(pessoa.nome) + ' se é golpe')));
    }
    acoes.append(ra);
    const textoVoz = 'Pare. ' + titulo + '. ' + (confTexto ? confTexto + ' ' : '') + motivos.join(' ') + ' O que fazer: ' + PASSOS[nivel];
    const ouvir = botaoOuvir(textoVoz);
    if (ouvir) ouvir.className = 'leve';
    const [l1, l2] = perigo ? ['Alerta', 'de golpe'] : ['Atenção', res.comercio ? 'loja suspeita' : 'site suspeito'];
    carregarFonte();

    const tela = el('div', {
      class: 'tela' + (simples ? ' grande' : '') + (config.daltonico ? ' daltonico' : ''), role: 'alertdialog', 'aria-modal': 'true', 'aria-labelledby': 'pg-tit'
    },
      el('div', { class: 'zebra', 'aria-hidden': 'true' }),
      el('div', { class: 'miolo' },
        el('div', { class: 'topo' },
          el('div', {},
            el('div', { class: 'h1 caps', id: 'pg-tit' }, el('span', { class: 'l1' }, l1), ' ', el('span', { class: 'l2' }, l2)),
            el('p', { class: 'sub' }, titulo + '.'),
            el('div', { class: 'host' }, location.hostname)),
          desenho('tri')),
        ...(confNum === null ? [] : [el('div', { class: 'conf' },
          el('span', { class: 'num caps' }, confNum + '%'),
          el('span', { class: 'rot caps' }, 'de', el('br'), 'confiança'),
          el('p', { class: 'conf-txt' }, 'Para ser considerado confiável, o site precisa passar de ' + limiteConf + '%.'))]),
        el('p', { class: 'grito caps' }, 'Não digite ', el('span', {}, 'senha, CPF'), ' nem dados do ', el('span', {}, 'cartão!')),
        el('p', { class: 'calmo' }, PASSOS[nivel]),
        acoes,
        el('section', {}, el('div', { class: 'h2 caps' }, 'O que encontramos'), el('ul', { class: 'lista' }, ...motivos.map((m) => el('li', {}, m)))),
        ...(ouvir ? [el('div', {}, ouvir)] : []),
        el('div', { class: 'rodape' }, continuar)));
    root.appendChild(tela);
    document.documentElement.appendChild(host);
    avisoSite = host;
    voltar.focus({ preventScroll: true });                       // Enter = ação segura; leitor de tela anuncia o alerta
    if (config.vozAutomatica) enviar({ tipo: 'falar', texto: textoVoz });
  }

  // ---------- 2) Página pedindo pagamento ----------
  // Sinais da página. O texto fica no computador; só vai ao fundo verdadeiro/falso de cada sinal.
  const PRESSAO = [
    /[úu]ltimas?\s+(unidades?|pe[cç]as?|horas?|vagas?)/i, /restam\s+(apenas\s+)?\d+/i, /s[óo]\s+hoje/i,
    /oferta\s+(termina|expira|acaba|por\s+tempo)/i, /por\s+tempo\s+limitado/i, /estoque\s+(limitado|acabando)/i,
    /aproveite\s+(agora|j[áa])/i, /garanta\s+(j[áa]|agora)/i, /agora\s+ou\s+nunca/i, /[úu]ltima\s+chance/i,
    /sua\s+conta\s+ser[áa]\s+(bloqueada|suspensa|cancelada)/i, /\d+\s+pessoas\s+(est[ãa]o|vendo|comprando)/i
  ];
  const PAGAMENTO = [
    /chave\s+pix/i, /pague\s+(agora|com\s+pix)/i, /finalizar\s+(a\s+)?compra/i, /boleto\s+banc[áa]rio/i,
    /n[úu]mero\s+do\s+cart[ãa]o/i, /c[óo]digo\s+de\s+seguran[çc]a|\bcvv\b/i, /pagamento\s+(via|por)\s+pix/i, /pix\s+copia\s+e\s+cola/i,
    /taxa\s+(de\s+)?(libera[cç][aã]o|desbloqueio)/i
  ];
  const CNPJ = /\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}/;
  const CONTATO = /fale\s+conosco|contato|atendimento|\bsac\b|quem\s+somos/i;

  function descontoExagerado(texto) {
    const re = /(\d{2,3})\s*%\s*(off|de\s+desconto|desconto)|desconto\s+de\s+(\d{2,3})\s*%/gi;
    let m;
    while ((m = re.exec(texto))) { if (Number(m[1] || m[3]) >= 70) return true; }
    return false;
  }

  const POLITICAS = [
    /pol[íi]tica\s+de\s+privacidade|privacidade/i, /termos\s+(de\s+)?(uso|servi[cç]o|compra)/i,
    /troca[s]?\s+e\s+devolu[cç][õo]es|pol[íi]tica\s+de\s+troca|devolu[cç][ãa]o/i,
    /prazo\s+de\s+entrega|pol[íi]tica\s+de\s+entrega|\bfrete\b/i
  ];
  const GATEWAYS = ['mercadopago.com', 'mercadopago.com.br', 'pagseguro.uol.com.br', 'pagbank.com.br', 'stripe.com',
    'paypal.com', 'pagar.me', 'cielo.com.br', 'stone.com.br', 'ebanx.com', 'hotmart.com', 'pix.bcb.gov.br'];
  const ENDERECO = /\b(rua|av\.?|avenida|alameda|rodovia|travessa)\s+[^,\n]{3,40},?\s*\d+/i;

  // Só título e cabeçalhos: um botão "Entrar com Google" num site legítimo não conta.
  const MARCAS_PAGINA = {
    microsoft: /\b(microsoft|outlook|office\s*365|onedrive|sharepoint)\b/i, google: /\b(google|gmail)\b/i,
    govbr: /\bgov\.?br\b|receita\s+federal|\bmeu\s+inss\b|\binss\b/i, nubank: /\bnubank\b/i, itau: /\bita[uú]\b/i,
    bradesco: /\bbradesco\b/i, caixa: /caixa\s+econ[oô]mica|\bcaixa\s+tem\b/i, santander: /\bsantander\b/i,
    bb: /banco\s+do\s+brasil/i, correios: /\bcorreios\b/i, mercadolivre: /mercado\s*livre/i, paypal: /\bpaypal\b/i,
    apple: /\bapple\s*id\b|\bicloud\b/i, netflix: /\bnetflix\b/i, instagram: /\binstagram\b/i,
    facebook: /\bfacebook\b/i, whatsapp: /\bwhatsapp\b/i
  };
  function marcasDaPagina() {
    const cab = [document.title, ...[...document.querySelectorAll('h1, h2')].slice(0, 6).map((e) => e.textContent)].join(' \n ');
    return Object.keys(MARCAS_PAGINA).filter((k) => MARCAS_PAGINA[k].test(cab));
  }

  function cnpjOk(d) {
    if (d.length !== 14 || /^(\d)\1+$/.test(d)) return false;
    const calc = (n) => { let s = 0, p = n - 7; for (let i = 0; i < n; i++) { s += Number(d[i]) * p--; if (p < 2) p = 9; } const r = s % 11; return r < 2 ? 0 : 11 - r; };
    return calc(12) === Number(d[12]) && calc(13) === Number(d[13]);
  }
  function hostEm(host, lista) { return lista.some((g) => host === g || host.endsWith('.' + g)); }

  function lerSinais() {
    const texto = (document.body ? document.body.innerText : '').slice(0, 100000);
    const campoCartao = !!document.querySelector('input[autocomplete^="cc-"], input[name*="card" i], input[name*="cartao" i], input[name*="cvv" i], input[id*="cvv" i]');
    const senha = !!document.querySelector('input[type="password"]');
    const pagamento = campoCartao || PAGAMENTO.some((p) => p.test(texto));
    const preco = (texto.match(/R\$\s?\d/g) || []).length;
    const venda = preco >= 1 && /adicionar\s+ao\s+carrinho|comprar\s+agora|\bcomprar\b|carrinho\s+de\s+compras|finalizar\s+compra/i.test(texto);
    const contador = !!document.querySelector('[class*="countdown" i], [id*="countdown" i], [class*="timer" i], [id*="timer" i]');
    const pressao = contador || PRESSAO.some((p) => p.test(texto));
    let formExterno = false, gateway = false;
    document.querySelectorAll('form[action], iframe[src]').forEach((f) => {
      try {
        const url = new URL(f.getAttribute('action') || f.getAttribute('src'), location.href);
        if (!/^https?:$/.test(url.protocol) || url.hostname === location.hostname) return;
        if (hostEm(url.hostname, GATEWAYS)) { gateway = true; return; }
        if (f.tagName === 'FORM' && f.querySelector('input[type="password"], input[autocomplete^="cc-"], input[name*="card" i], input[name*="cpf" i], input[name*="senha" i]')) formExterno = true;
      } catch (e) { /* endereço inválido */ }
    });
    let cnpjValido = false, cnpjInvalido = false, cnpj = '';
    for (const m of texto.matchAll(new RegExp(CNPJ.source, 'g'))) {
      const d = m[0].replace(/\D/g, '');
      if (cnpjOk(d)) { cnpjValido = true; if (!cnpj) cnpj = d; } else cnpjInvalido = true;
    }
    if (cnpjValido) cnpjInvalido = false;
    const raiz = location.hostname.replace(/^www\./, '');
    const emails = [...texto.matchAll(/[\w.+-]+@([\w.-]+\.[a-z]{2,})/gi)].map((m) => m[1].toLowerCase());
    document.querySelectorAll('a[href^="mailto:"]').forEach((a) => { const m = a.getAttribute('href').match(/@([\w.-]+)/); if (m) emails.push(m[1].toLowerCase()); });
    const emailMesmoDominio = emails.some((d) => d === raiz || d.endsWith('.' + raiz) || raiz.endsWith('.' + d));
    const contato = CONTATO.test(texto) || ENDERECO.test(texto) || emails.length > 0 || !!document.querySelector('a[href^="tel:"]');
    const politicas = POLITICAS.filter((p) => p.test(texto)).length >= 2;
    return { pagamento, pressao, desconto: descontoExagerado(texto), formExterno, senha, venda,
      semContato: pagamento && !(CNPJ.test(texto) || contato), cnpjValido, cnpjInvalido, contato, emailMesmoDominio, politicas, gateway,
      marcas: (senha || pagamento) ? marcasDaPagina() : [], cnpj };
  }

  function mostrarAvisoPagamento() {
    const simples = !!config.modoSimples;
    const { host, root } = criarCaixa({
      position: 'fixed', bottom: '0', left: '0', right: '0', 'z-index': '2147483647', display: 'block'
    });
    const passo = 'Antes de pagar, ligue para um familiar de confiança.';
    const faixa = el('div', { class: 'faixa atencao' + (simples ? ' grande' : ''), role: 'status', 'aria-live': 'polite' },
      el('div', { class: 'cab' }, icone('atencao'),
        el('div', {}, el('div', { class: 'palavra' }, 'ATENÇÃO'),
          el('div', { class: 'titulo' }, 'Pare e pense: esta página pede dinheiro'))),
      el('div', { class: 'passo' }, el('b', {}, 'O que fazer: '), passo));
    const ouvir = botaoOuvir('Atenção. Pare e pense: esta página pede dinheiro. ' + passo);
    if (ouvir) faixa.append(ouvir);
    faixa.append(el('button', { type: 'button', onclick: () => host.remove() }, 'Entendi, fechar'));
    root.appendChild(faixa);
    document.documentElement.appendChild(host);
  }

  let ultimoEnvio = '';
  async function checarPagina() {
    if (!ativo || rodadas++ >= 6 || !document.body) return;
    if (siteRes && siteRes.conhecido) return;               // site provado: não incomoda
    const sinais = lerSinais();
    const chave = JSON.stringify(sinais);
    const gatilho = sinais.pagamento || sinais.venda || sinais.pressao || sinais.desconto || sinais.formExterno || sinais.senha;
    if (!gatilho || chave === ultimoEnvio) return;
    ultimoEnvio = chave;
    const res = await enviar({ tipo: 'avaliar-pagina', host: location.hostname, protocolo: location.protocol, url: location.href, sinais });
    if (res) { siteRes = res; if (res.nivel !== 'ok') mostrarAvisoSite(res); }
  }

  // ---------- 3) Posts, imagens e vídeos ----------
  const ROTULOS_IA = /(feito com ia|criado com ia|gerado por ia|informa[cç][õo]es? (de|sobre) ia|ai info|made with ai|ai[- ]generated|conte[úu]do sint[ée]tico|alterado ou sint[ée]tico|altered or synthetic)/i;
  const SINAIS_GOLPE = [
    /investimento\s+garantido/i, /lucro\s+(garantido|certo|di[aá]rio)/i,
    /(fa[cç]a|mande|envie)\s+(um\s+)?pix/i, /dobre\s+seu\s+dinheiro/i,
    /taxa\s+(de\s+)?(libera[cç][aã]o|desbloqueio)/i,
    /voc[eê]\s+(foi\s+)?(ganhou|sorteado)/i,
    /(governo|banco|bndes)[^.\n]{0,60}(libera|indeniza|restitui)/i
  ];
  const ENCURTADORES = ['bit.ly', 'tinyurl.com', 'cutt.ly', 'is.gd', 'rb.gy', 't.co'];
  const PATROCINADO = /^(patrocinado|sponsored|publicidade|an[uú]ncio)$/i;
  const CONTAINERS = 'article, [role="article"], ytd-rich-item-renderer, ytd-video-renderer';

  function rotuloCurto(container, regex) {
    const itens = container.querySelectorAll('span, a, div[role="button"], [aria-label]');
    const max = Math.min(itens.length, 400);
    for (let i = 0; i < max; i++) {
      const t = (itens[i].getAttribute('aria-label') || itens[i].textContent || '').trim();
      if (t.length > 0 && t.length < 60 && regex.test(t)) return true;
    }
    return false;
  }

  function temLinkEncurtado(container) {
    const links = container.querySelectorAll('a[href]');
    const max = Math.min(links.length, 60);
    for (let i = 0; i < max; i++) {
      try {
        if (ENCURTADORES.includes(new URL(links[i].href).hostname)) return true;
      } catch (e) { /* href inválido */ }
    }
    return false;
  }

  function calcularRisco(container) {
    let pontos = 0;
    if (rotuloCurto(container, ROTULOS_IA)) pontos += 3;
    if (rotuloCurto(container, PATROCINADO)) pontos += 1;
    if (temLinkEncurtado(container)) pontos += 1;
    const texto = (container.textContent || '').slice(0, 6000);   // textContent não força layout
    pontos += SINAIS_GOLPE.filter((p) => p.test(texto)).length;
    return pontos;
  }

  function proteger(container, motivo) {
    if (container.dataset.pgProtegido) return;
    container.dataset.pgProtegido = '1';
    const midias = container.querySelectorAll('img, video');
    midias.forEach((m) => {
      m.style.setProperty('filter', 'blur(14px)', 'important');
      m.style.setProperty('outline', '4px solid #c62828', 'important');
      if (m.tagName === 'VIDEO') { m.pause(); m.autoplay = false; m.muted = true; }
    });
    const { host, root } = criarCaixa({ display: 'block' });
    const aviso = el('div', { class: 'aviso', role: 'alert' },
      icone('perigo', true),
      el('span', {}, el('b', {}, 'CUIDADO: '), motivo + ' Não envie dinheiro nem dados por causa disso.'),
      el('button', {
        type: 'button',
        onclick: () => {
          midias.forEach((m) => { m.style.removeProperty('filter'); m.style.removeProperty('outline'); });
          host.remove();
        }
      }, 'Ver mesmo assim'));
    root.appendChild(aviso);
    try { container.prepend(host); } catch (e) { /* o site pode bloquear a inserção */ }
  }

  const urlsVistas = new Set();
  function checarImagens(container) {
    if (!config.imagens) return;
    container.querySelectorAll('img').forEach((img) => {
      const checar = async () => {
        if (img.naturalWidth < 200 || img.naturalHeight < 200) return;
        const url = img.currentSrc || img.src;
        if (!url || !url.startsWith('https:') || urlsVistas.has(url)) return;
        urlsVistas.add(url);
        const r = await enviar({ tipo: 'metadados-imagem', url });
        if (r && r.ia) proteger(container, 'esta imagem tem marca de ter sido feita por inteligência artificial.');
      };
      if (img.complete) checar(); else img.addEventListener('load', checar, { once: true });
    });
  }

  function avaliar(container) {
    if (!ativo || container.dataset.pgProtegido) return;
    if (calcularRisco(container) >= config.limite) {
      proteger(container, 'este conteúdo tem vários sinais de golpe ou foi marcado como feito por IA.');
    } else {
      checarImagens(container);
    }
  }

  // Só avalia o que aparece na tela, uma vez por post.
  const obsInt = new IntersectionObserver((entradas) => {
    for (const e of entradas) {
      if (!e.isIntersecting) continue;
      obsInt.unobserve(e.target);
      const f = () => avaliar(e.target);
      if ('requestIdleCallback' in window) requestIdleCallback(f, { timeout: 2000 }); else setTimeout(f, 200);
    }
  }, { rootMargin: '200px' });

  function observar(c) {
    if (c.dataset.pgVisto) return;
    c.dataset.pgVisto = '1';
    obsInt.observe(c);
  }
  function registrar(no) {
    if (no.nodeType !== 1) return;
    if (no.matches && no.matches(CONTAINERS)) observar(no);
    if (no.querySelectorAll) no.querySelectorAll(CONTAINERS).forEach(observar);
  }

  // Olha só os nós novos, em lote.
  const pendentes = new Set();
  let timer = null;
  const obsMut = new MutationObserver((muts) => {
    for (const m of muts) m.addedNodes.forEach((n) => { if (n.nodeType === 1) pendentes.add(n); });
    if (pendentes.size > 1500) { pendentes.clear(); pendentes.add(document.documentElement); }
    if (timer) return;
    timer = setTimeout(() => {
      timer = null;
      const lote = [...pendentes];
      pendentes.clear();
      lote.forEach(registrar);
      checarPagina();
    }, 700);
  });

  function desligar() {
    ativo = false;
    try { obsMut.disconnect(); obsInt.disconnect(); } catch (e) { /* já desligado */ }
  }

  // ---------- Modo de teste (botões do popup) ----------
  const MOTIVOS_DEMO = {
    perigo: ['Aviso de teste: este site não foi analisado de verdade.',
      'O endereço parece imitar "nubank", mas o site oficial é nubank.com.br.',
      'A terminação .xyz é muito usada em golpes.', 'Este site foi criado há apenas 3 dias.'],
    atencao: ['Aviso de teste: este site não foi analisado de verdade.',
      'O site não usa conexão segura (sem cadeado).', 'O endereço tem palavras de pressão ou de acesso a conta.']
  };
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.tipo !== 'demo') return;
    if (msg.nivel === 'pagamento') {
      mostrarAvisoPagamento();
    } else if (MOTIVOS_DEMO[msg.nivel]) {
      if (fecharAvisoAtual) fecharAvisoAtual();
      avisoSite = null;
      mostrarAvisoSite({ nivel: msg.nivel, dominio: location.hostname, motivos: MOTIVOS_DEMO[msg.nivel] });
    }
    sendResponse({ ok: true });
  });

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.tipo === 'sinais') { sendResponse({ sinais: lerSinais(), nota: siteRes ? siteRes.pontos : 0 }); }
  });

  // ---------- Início ----------
  obsMut.observe(document.documentElement, { childList: true, subtree: true });
  registrar(document.documentElement);

  // Espera a configuração carregar para o aviso já sair no tamanho certo.
  const configPronta = chrome.storage.local.get(['config', 'pessoaConfianca']).then((d) => {
    if (d.config) Object.assign(config, d.config);
    pessoa = d.pessoaConfianca || null;
  }).catch(() => {});
  configPronta.then(() => enviar({ tipo: 'checar-site', host: location.hostname, protocolo: location.protocol, url: location.href }))
    .then((res) => {
      siteRes = res;
      if (res && res.nivel !== 'ok') mostrarAvisoSite(res);
      checarPagina();
    });
})();
